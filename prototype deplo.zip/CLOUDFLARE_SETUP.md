# LeadIQ Enterprise Dashboard - Cloudflare Workers Setup Guide

## Overview
This guide will help you deploy your AI Dynamic Scoring CRM Dashboard on Cloudflare Workers with backend integration.

---

## Option 1: Static HTML Deployment (Fastest)

### Step 1: Create Cloudflare Worker
```bash
# Install Wrangler CLI
npm install -g wrangler

# Create new project
wrangler init crm-dashboard

# Navigate to project
cd crm-dashboard
```

### Step 2: Deploy HTML File
**Method A: Using `index.html`**
```bash
# Create public folder
mkdir -p public

# Copy the HTML file
cp crm-dashboard-cloudflare.html public/index.html

# Deploy
wrangler publish
```

**Method B: Using `src/index.js`**
Create `src/index.js`:
```javascript
const html = `<!DOCTYPE html>...`; // Copy entire HTML from crm-dashboard-cloudflare.html

export default {
  fetch: async (request) => {
    return new Response(html, {
      headers: { 'Content-Type': 'text/html; charset=utf-8' },
    });
  },
};
```

Then deploy:
```bash
wrangler publish
```

---

## Option 2: Dynamic Backend Integration

### Step 1: Set Up API Endpoints
Create `src/index.js` with dynamic API handling:

```javascript
// Cloudflare Workers Script
export default {
  async fetch(request, env) {
    const url = new URL(request.url);

    // Route API calls
    if (url.pathname.startsWith('/api/')) {
      return handleAPI(request, url, env);
    }

    // Serve HTML for all other requests
    return serveHTML(request);
  },
};

async function handleAPI(request, url, env) {
  const path = url.pathname.split('/api/')[1];

  switch (path) {
    case 'leads':
      return handleLeadsAPI(request, env);
    case 'score':
      return handleScoringAPI(request, env);
    case 'timeline':
      return handleTimelineAPI(request, env);
    default:
      return new Response('Not Found', { status: 404 });
  }
}

async function handleLeadsAPI(request, env) {
  if (request.method === 'GET') {
    // Fetch from your backend/database
    const leads = await fetch('YOUR_BACKEND_API/leads', {
      headers: {
        'Authorization': `Bearer ${env.API_KEY}`,
      },
    }).then(r => r.json());

    return new Response(JSON.stringify(leads), {
      headers: { 'Content-Type': 'application/json' },
    });
  }

  return new Response('Method Not Allowed', { status: 405 });
}

async function handleScoringAPI(request, env) {
  if (request.method === 'POST') {
    const data = await request.json();
    
    // Call your AI scoring backend
    const score = await fetch('YOUR_SCORING_API/calculate', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${env.SCORING_API_KEY}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(data),
    }).then(r => r.json());

    return new Response(JSON.stringify(score), {
      headers: { 'Content-Type': 'application/json' },
    });
  }

  return new Response('Method Not Allowed', { status: 405 });
}

async function handleTimelineAPI(request, env) {
  if (request.method === 'GET') {
    const leadId = new URL(request.url).searchParams.get('leadId');
    
    // Fetch timeline events
    const timeline = await fetch(`YOUR_BACKEND_API/timeline?leadId=${leadId}`, {
      headers: {
        'Authorization': `Bearer ${env.API_KEY}`,
      },
    }).then(r => r.json());

    return new Response(JSON.stringify(timeline), {
      headers: { 'Content-Type': 'application/json' },
    });
  }

  return new Response('Method Not Allowed', { status: 405 });
}

function serveHTML(request) {
  const html = `<!DOCTYPE html>...[paste entire HTML here]`;
  
  return new Response(html, {
    headers: {
      'Content-Type': 'text/html; charset=utf-8',
      'Cache-Control': 'public, max-age=3600',
    },
  });
}
```

### Step 2: Configure Environment Variables
Create `wrangler.toml`:
```toml
name = "crm-dashboard"
type = "javascript"
account_id = "YOUR_ACCOUNT_ID"
workers_dev = true
route = "https://crm.example.com/*"
zone_id = "YOUR_ZONE_ID"

[env.production]
vars = { ENVIRONMENT = "production" }

[env.staging]
vars = { ENVIRONMENT = "staging" }

[build.upload]
format = "modules"
```

### Step 3: Add Secrets
```bash
# Add API keys securely
wrangler secret put API_KEY
wrangler secret put SCORING_API_KEY
wrangler secret put STRIPE_KEY
```

### Step 4: Deploy
```bash
# Deploy to production
wrangler publish --env production

# Or staging
wrangler publish --env staging
```

---

## Option 3: Using Cloudflare Pages (Recommended for Static)

### Step 1: Create Git Repository
```bash
git init
git add crm-dashboard-cloudflare.html
git commit -m "Initial CRM dashboard"
git push origin main
```

### Step 2: Connect to Cloudflare Pages
1. Go to Cloudflare Dashboard → Pages
2. Click "Create a project" → "Connect to Git"
3. Select your repository
4. Set build command: `echo "No build needed"`
5. Set publish directory: `.`
6. Deploy

### Step 3: Custom Domain
In Cloudflare Pages settings:
- Add custom domain: `crm.example.com`
- Update DNS records automatically

---

## Backend Integration Examples

### Node.js/Express Backend
```javascript
// Example backend API
const express = require('express');
const app = express();

app.get('/api/leads/:id', async (req, res) => {
  const lead = {
    id: req.params.id,
    name: 'Arun Kumar',
    email: 'arun.k@abctech.com',
    role: 'Chief Technology Officer',
    company: 'ABC Technologies',
    score: 94,
    status: 'hot_lead',
  };
  res.json(lead);
});

app.post('/api/score/calculate', async (req, res) => {
  const { factors } = req.body;
  const score = calculateScore(factors);
  res.json({ score, confidence: 96 });
});

app.get('/api/timeline/:leadId', async (req, res) => {
  const timeline = [
    { time: '09:42 AM', event: 'Inbound Arrival', type: 'arrival' },
    { time: '10:21 AM', event: 'Critical Elevation', type: 'critical' },
  ];
  res.json(timeline);
});

app.listen(3000);
```

### Python/FastAPI Backend
```python
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware

app = FastAPI()

app.add_middleware(
    CORSMiddleware,
    allow_origins=["https://crm.example.com"],
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.get("/api/leads/{lead_id}")
async def get_lead(lead_id: str):
    return {
        "id": lead_id,
        "name": "Arun Kumar",
        "score": 94,
        "status": "hot_lead"
    }

@app.post("/api/score/calculate")
async def calculate_score(factors: dict):
    score = sum(factors.values())
    return {"score": score, "confidence": 96}

@app.get("/api/timeline/{lead_id}")
async def get_timeline(lead_id: str):
    return [
        {"time": "09:42 AM", "event": "Inbound Arrival"},
        {"time": "10:21 AM", "event": "Critical Elevation"}
    ]
```

---

## Frontend Integration (Vanilla JS)

### Fetch Lead Data
```javascript
async function loadLeadData(leadId) {
  try {
    const response = await fetch(`/api/leads/${leadId}`);
    const lead = await response.json();
    
    // Update UI
    document.querySelector('.profile-name').textContent = lead.name;
    document.querySelector('.profile-role').textContent = lead.role;
    document.querySelector('.score-value').textContent = lead.score;
  } catch (error) {
    console.error('Error loading lead:', error);
  }
}

// Call on page load
document.addEventListener('DOMContentLoaded', () => {
  const leadId = new URLSearchParams(window.location.search).get('lead');
  if (leadId) {
    loadLeadData(leadId);
  }
});
```

### Real-time Scoring Updates
```javascript
async function calculateScore(factors) {
  try {
    const response = await fetch('/api/score/calculate', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ factors }),
    });
    
    const result = await response.json();
    updateScoreUI(result.score, result.confidence);
  } catch (error) {
    console.error('Scoring error:', error);
  }
}

function updateScoreUI(score, confidence) {
  const gaugeWidth = (score / 100) * 360;
  document.querySelector('.score-gauge').style.background = 
    `conic-gradient(var(--primary) 0deg ${gaugeWidth}deg, var(--border-light) ${gaugeWidth}deg 360deg)`;
  
  document.querySelector('.score-value').textContent = score;
  document.querySelector('[class*="confidence"]').textContent = `${confidence}%`;
}
```

### Load Timeline Events
```javascript
async function loadTimeline(leadId) {
  try {
    const response = await fetch(`/api/timeline/${leadId}`);
    const events = await response.json();
    
    const timeline = document.querySelector('.timeline');
    timeline.innerHTML = events.map(event => `
      <div class="timeline-item">
        <div class="timeline-dot"></div>
        <div class="timeline-time">${event.time}</div>
        <div class="timeline-event">${event.event}</div>
      </div>
    `).join('');
  } catch (error) {
    console.error('Error loading timeline:', error);
  }
}
```

---

## Performance Optimization

### Add Caching Headers
```javascript
// In Cloudflare Worker
headers.set('Cache-Control', 'public, max-age=3600, s-maxage=86400');
headers.set('CDN-Cache-Control', 'max-age=86400');
```

### Enable Compression
```toml
# In wrangler.toml
[build]
cwd = "."
command = "npm run build"
watch_paths = ["src/**/*.js"]
```

### Image Optimization
The dashboard uses placeholder images. Replace with optimized images:
```html
<!-- Instead of -->
<img src="https://via.placeholder.com/80/667eea/667eea" alt="Avatar">

<!-- Use -->
<img src="https://cdn.example.com/avatars/arun.jpg" alt="Avatar" loading="lazy">
```

---

## Deployment Checklist

- [ ] HTML file created and tested locally
- [ ] Cloudflare account configured
- [ ] Environment variables set (API keys, tokens)
- [ ] Backend API endpoints ready
- [ ] CORS properly configured
- [ ] SSL/TLS certificate installed
- [ ] Custom domain configured
- [ ] Cache rules set
- [ ] Security headers configured
- [ ] Testing completed
- [ ] Analytics enabled
- [ ] Monitoring alerts set

---

## Troubleshooting

### CORS Errors
```javascript
// Add CORS headers in Worker
headers.set('Access-Control-Allow-Origin', 'https://crm.example.com');
headers.set('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE');
headers.set('Access-Control-Allow-Headers', 'Content-Type, Authorization');
```

### API Timeouts
```javascript
// Add timeout handling
const controller = new AbortController();
const timeout = setTimeout(() => controller.abort(), 5000);

try {
  const response = await fetch(url, { signal: controller.signal });
} finally {
  clearTimeout(timeout);
}
```

### Dark Mode Not Working
Ensure system prefers-color-scheme is set:
```css
@media (prefers-color-scheme: dark) {
  /* Dark mode styles */
}
```

---

## Support & Documentation

- [Cloudflare Workers Documentation](https://developers.cloudflare.com/workers/)
- [Cloudflare Pages Documentation](https://developers.cloudflare.com/pages/)
- [Wrangler CLI Reference](https://developers.cloudflare.com/workers/wrangler/install-and-update/)

---

## Next Steps

1. **Customize Design**: Modify CSS variables in `<style>` section
2. **Add Features**: Implement real-time updates with WebSockets
3. **Connect Database**: Integrate with your CRM database
4. **Enable Analytics**: Set up Cloudflare Analytics Engine
5. **Scale Globally**: Use Cloudflare's global CDN

---

**Generated**: 2026-09-30
**Version**: 1.0
**License**: MIT
