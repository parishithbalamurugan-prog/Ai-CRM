/**
 * LeadIQ Enterprise - Cloudflare Worker
 * Deploy directly to Cloudflare Workers
 * 
 * Usage:
 * 1. Copy this entire file
 * 2. Go to Cloudflare Dashboard → Workers
 * 3. Create new Worker → Paste this code
 * 4. Deploy
 * 5. Update the backend URLs below
 */

const BACKEND_URL = 'https://api.example.com'; // Replace with your backend
const API_KEY = 'your-api-key-here'; // Set via Cloudflare Secrets

export default {
  async fetch(request, env, ctx) {
    const url = new URL(request.url);

    // Route API calls to backend
    if (url.pathname.startsWith('/api/')) {
      return handleAPI(request, url, env);
    }

    // Serve dashboard HTML
    return serveDashboard(request);
  },
};

/**
 * Handle API requests
 */
async function handleAPI(request, url, env) {
  const path = url.pathname.substring(5); // Remove '/api/' prefix

  try {
    // Route-based handling
    if (path.startsWith('leads/')) {
      return handleLeadsAPI(request, url, env);
    }
    
    if (path.startsWith('score/')) {
      return handleScoringAPI(request, url, env);
    }
    
    if (path.startsWith('timeline/')) {
      return handleTimelineAPI(request, url, env);
    }
    
    if (path.startsWith('recommendations/')) {
      return handleRecommendationsAPI(request, url, env);
    }

    // Default 404
    return jsonResponse({ error: 'Not Found' }, 404);
  } catch (error) {
    console.error('API Error:', error);
    return jsonResponse({ error: 'Internal Server Error', details: error.message }, 500);
  }
}

/**
 * Handle Leads API
 * GET  /api/leads/:id       - Get specific lead
 * GET  /api/leads           - Get all leads
 * POST /api/leads           - Create new lead
 */
async function handleLeadsAPI(request, url, env) {
  const leadId = url.pathname.split('/').pop();

  switch (request.method) {
    case 'GET':
      return await getLeads(leadId, env);
    case 'POST':
      return await createLead(request, env);
    case 'PUT':
      return await updateLead(leadId, request, env);
    case 'DELETE':
      return await deleteLead(leadId, env);
    default:
      return jsonResponse({ error: 'Method not allowed' }, 405);
  }
}

async function getLeads(leadId, env) {
  const url = leadId 
    ? `${BACKEND_URL}/leads/${leadId}`
    : `${BACKEND_URL}/leads`;

  const response = await fetch(url, {
    method: 'GET',
    headers: {
      'Authorization': `Bearer ${env.API_KEY}`,
      'Content-Type': 'application/json',
    },
  });

  const data = await response.json();
  return jsonResponse(data, response.status);
}

async function createLead(request, env) {
  const body = await request.json();

  const response = await fetch(`${BACKEND_URL}/leads`, {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${env.API_KEY}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify(body),
  });

  const data = await response.json();
  return jsonResponse(data, response.status);
}

async function updateLead(leadId, request, env) {
  const body = await request.json();

  const response = await fetch(`${BACKEND_URL}/leads/${leadId}`, {
    method: 'PUT',
    headers: {
      'Authorization': `Bearer ${env.API_KEY}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify(body),
  });

  const data = await response.json();
  return jsonResponse(data, response.status);
}

async function deleteLead(leadId, env) {
  const response = await fetch(`${BACKEND_URL}/leads/${leadId}`, {
    method: 'DELETE',
    headers: {
      'Authorization': `Bearer ${env.API_KEY}`,
    },
  });

  return jsonResponse({ success: true }, response.status);
}

/**
 * Handle AI Scoring API
 * POST /api/score/calculate - Calculate lead score
 */
async function handleScoringAPI(request, url, env) {
  if (request.method !== 'POST') {
    return jsonResponse({ error: 'Method not allowed' }, 405);
  }

  const body = await request.json();

  const response = await fetch(`${BACKEND_URL}/score/calculate`, {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${env.API_KEY}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify(body),
  });

  const data = await response.json();
  return jsonResponse(data, response.status);
}

/**
 * Handle Timeline API
 * GET /api/timeline/:leadId - Get lead timeline
 */
async function handleTimelineAPI(request, url, env) {
  if (request.method !== 'GET') {
    return jsonResponse({ error: 'Method not allowed' }, 405);
  }

  const leadId = url.pathname.split('/').pop();

  const response = await fetch(`${BACKEND_URL}/timeline/${leadId}`, {
    method: 'GET',
    headers: {
      'Authorization': `Bearer ${env.API_KEY}`,
      'Content-Type': 'application/json',
    },
  });

  const data = await response.json();
  return jsonResponse(data, response.status);
}

/**
 * Handle Recommendations API
 * POST /api/recommendations/:leadId - Get AI recommendations
 */
async function handleRecommendationsAPI(request, url, env) {
  if (request.method !== 'POST') {
    return jsonResponse({ error: 'Method not allowed' }, 405);
  }

  const leadId = url.pathname.split('/').pop();
  const body = await request.json();

  const response = await fetch(`${BACKEND_URL}/recommendations/${leadId}`, {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${env.API_KEY}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify(body),
  });

  const data = await response.json();
  return jsonResponse(data, response.status);
}

/**
 * Serve Dashboard HTML
 */
async function serveDashboard(request) {
  // Cache for 1 hour
  const cacheHeaders = new Headers({
    'Cache-Control': 'public, max-age=3600',
    'Content-Type': 'text/html; charset=utf-8',
  });

  // Serve inline HTML (paste your crm-dashboard-cloudflare.html content here)
  const html = `<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>LeadIQ Enterprise - AI Dynamic Scoring Dashboard</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        :root {
            --primary: #4b41e1;
            --primary-dark: #3d32b8;
            --bg-light: #f8f9ff;
            --bg-white: #ffffff;
            --text-primary: #0b1c30;
            --text-secondary: #45464d;
            --border-light: #e5eeff;
            --border-lighter: #dce9ff;
            --warning: #ba1a1a;
            --warning-light: #ffdad6;
            --info-light: #eff4ff;
            --shadow-sm: 0px 1px 2px rgba(0, 0, 0, 0.05);
            --shadow-md: 0px 1px 8px rgba(0, 0, 0, 0.04);
        }

        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', 'Inter', sans-serif;
            background: linear-gradient(90deg, var(--bg-light) 0%, var(--bg-light) 100%);
            color: var(--text-primary);
            line-height: 1.6;
            min-height: 100vh;
        }

        .container {
            display: flex;
            height: 100vh;
            background: var(--bg-white);
        }

        .main-content {
            flex: 1;
            overflow-y: auto;
            background: var(--bg-light);
            padding: 40px;
            display: flex;
            align-items: center;
            justify-content: center;
            text-align: center;
        }

        .loading-state {
            display: flex;
            flex-direction: column;
            gap: 20px;
            align-items: center;
        }

        .spinner {
            border: 4px solid var(--border-light);
            border-top-color: var(--primary);
            border-radius: 50%;
            width: 40px;
            height: 40px;
            animation: spin 0.8s linear infinite;
        }

        @keyframes spin {
            to { transform: rotate(360deg); }
        }

        .message {
            font-size: 18px;
            color: var(--text-primary);
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="main-content">
            <div class="loading-state">
                <div class="spinner"></div>
                <div class="message">Loading Dashboard...</div>
                <p style="color: var(--text-secondary); margin-top: 10px;">Replace this with your crm-dashboard-cloudflare.html content</p>
            </div>
        </div>
    </div>

    <script>
        // API Integration Example
        async function loadDashboard() {
            try {
                const leadId = new URLSearchParams(window.location.search).get('lead') || '12345';
                
                // Fetch lead data
                const leadResponse = await fetch(\`/api/leads/\${leadId}\`);
                const lead = await leadResponse.json();
                
                console.log('Lead loaded:', lead);
                
                // Fetch timeline
                const timelineResponse = await fetch(\`/api/timeline/\${leadId}\`);
                const timeline = await timelineResponse.json();
                
                console.log('Timeline loaded:', timeline);
                
                // Update UI (implement your UI update logic here)
            } catch (error) {
                console.error('Error loading dashboard:', error);
            }
        }

        // Load on page ready
        document.addEventListener('DOMContentLoaded', loadDashboard);
    </script>
</body>
</html>`;

  return new Response(html, { headers: cacheHeaders });
}

/**
 * Utility: JSON Response Helper
 */
function jsonResponse(data, status = 200) {
  return new Response(JSON.stringify(data), {
    status,
    headers: {
      'Content-Type': 'application/json',
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS',
      'Access-Control-Allow-Headers': 'Content-Type, Authorization',
    },
  });
}

/**
 * CORS Handling for OPTIONS requests
 */
function handleOptions(request) {
  return new Response(null, {
    headers: {
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS',
      'Access-Control-Allow-Headers': 'Content-Type, Authorization',
      'Access-Control-Max-Age': '86400',
    },
  });
}

// Handle OPTIONS for CORS
if (request.method === 'OPTIONS') {
  return handleOptions(request);
}
